require File.dirname(__FILE__) + '/../test_helper'

class ArticleTest < ActiveSupport::TestCase
  fixtures :articles

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
